<div {!! $attributes->merge(['class' => 'px-4 py-3 mb-8 bg-white rounded-md shadow-md dark:shadow-card dark:bg-gray-800']) !!}>
    {{$slot}}
</div>
