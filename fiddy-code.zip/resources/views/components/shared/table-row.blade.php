<tr {!! $attributes->merge(['class' => 'text-gray-700 dark:text-gray-400 hover:bg-gray-50 dark:hover:bg-dark1 dark:bg-dark2']) !!}>
    {{ $slot }}
</tr>