<?php if (isset($component)) { $__componentOriginal69dc84650370d1d4dc1b42d016d7226b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal69dc84650370d1d4dc1b42d016d7226b = $attributes; } ?>
<?php $component = App\View\Components\GuestLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('guest-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\GuestLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <?php $__env->startSection('title', 'Kitchen Estimator'); ?>

    
    <div class="flex flex-col items-center gap-1">
        <h1 class="text-3xl font-bold text-gray-800 dark:text-gray-800 text-center">
            Home Interior Price Estimator
        </h1>
        <div class="h-1 bg-primary w-16"></div>
    </div>

    <div class="mt-10 px-2 sm:px-5 pb-32" id="formContainer">
        <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('forms.interior-estimator-form');

$__html = app('livewire')->mount($__name, $__params, 'lw-1341930468-0', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
    </div>

    <?php $__env->startPush('scripts'); ?>
        <script>

            function openModal(modalId) {
                setTimeout(()=>{document.getElementById(modalId).showModal();},100);
            }
            function closeModal(modalId) {
                setTimeout(()=>{document.getElementById(modalId).close();},100);
            }

            window.closeModal=closeModal;

            window.addEventListener("openModal", event=> {
                const modalId = event.detail.modalId;
                openModal(modalId);
            });

            window.addEventListener("closeModal", event=> {
                const modalId = event.detail.modalId;
                closeModal(modalId);
            });

            function resizeIframe () {
                const height = document.getElementById('formContainer').offsetHeight;

                console.log(height);

                //  Send a message to the parent window to resize the iframe
                window.parent.postMessage({ resizeIframe: true, height: height+200 }, '*');
            }
            // window.onload = resizeIframe;

            window.addEventListener("triggerResize", resizeIframe);
        </script>
    <?php $__env->stopPush(); ?>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal69dc84650370d1d4dc1b42d016d7226b)): ?>
<?php $attributes = $__attributesOriginal69dc84650370d1d4dc1b42d016d7226b; ?>
<?php unset($__attributesOriginal69dc84650370d1d4dc1b42d016d7226b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal69dc84650370d1d4dc1b42d016d7226b)): ?>
<?php $component = $__componentOriginal69dc84650370d1d4dc1b42d016d7226b; ?>
<?php unset($__componentOriginal69dc84650370d1d4dc1b42d016d7226b); ?>
<?php endif; ?><?php /**PATH D:\PROJECTS\Laravel\fiddy-laravel\resources\views/fiddy/interior-estimator.blade.php ENDPATH**/ ?>