<div >
    <!--[if BLOCK]><![endif]--><?php if($step==1): ?>
    <form wire:submit.prevent="openForm">
        <?php echo csrf_field(); ?>
        <?php if (isset($component)) { $__componentOriginalb24df6adf99a77ed35057e476f61e153 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb24df6adf99a77ed35057e476f61e153 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.validation-errors','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('validation-errors'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb24df6adf99a77ed35057e476f61e153)): ?>
<?php $attributes = $__attributesOriginalb24df6adf99a77ed35057e476f61e153; ?>
<?php unset($__attributesOriginalb24df6adf99a77ed35057e476f61e153); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb24df6adf99a77ed35057e476f61e153)): ?>
<?php $component = $__componentOriginalb24df6adf99a77ed35057e476f61e153; ?>
<?php unset($__componentOriginalb24df6adf99a77ed35057e476f61e153); ?>
<?php endif; ?>
        <p class="mb-3 font-bold">Please select door type:</p>
        <div class="grid grid-cols-2 sm:grid-cols-4  w-full gap-5">
            <?php if (isset($component)) { $__componentOriginal3a018e5b1027c2d16e74e902b228c453 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3a018e5b1027c2d16e74e902b228c453 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.shared.image-radio','data' => ['id' => 'wardrobe_type_hinged','name' => 'wardrobe_type','src' => ''.e(asset('images/fiddy/wardrobe/hinged.png')).'','wire:model.live' => 'wardrobe_type','value' => 'hinged']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('shared.image-radio'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'wardrobe_type_hinged','name' => 'wardrobe_type','src' => ''.e(asset('images/fiddy/wardrobe/hinged.png')).'','wire:model.live' => 'wardrobe_type','value' => 'hinged']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3a018e5b1027c2d16e74e902b228c453)): ?>
<?php $attributes = $__attributesOriginal3a018e5b1027c2d16e74e902b228c453; ?>
<?php unset($__attributesOriginal3a018e5b1027c2d16e74e902b228c453); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3a018e5b1027c2d16e74e902b228c453)): ?>
<?php $component = $__componentOriginal3a018e5b1027c2d16e74e902b228c453; ?>
<?php unset($__componentOriginal3a018e5b1027c2d16e74e902b228c453); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginal3a018e5b1027c2d16e74e902b228c453 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3a018e5b1027c2d16e74e902b228c453 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.shared.image-radio','data' => ['id' => 'wardrobe_type_sliding','name' => 'wardrobe_type','src' => ''.e(asset('images/fiddy/wardrobe/sliding.png')).'','wire:model.live' => 'wardrobe_type','value' => 'sliding']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('shared.image-radio'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'wardrobe_type_sliding','name' => 'wardrobe_type','src' => ''.e(asset('images/fiddy/wardrobe/sliding.png')).'','wire:model.live' => 'wardrobe_type','value' => 'sliding']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3a018e5b1027c2d16e74e902b228c453)): ?>
<?php $attributes = $__attributesOriginal3a018e5b1027c2d16e74e902b228c453; ?>
<?php unset($__attributesOriginal3a018e5b1027c2d16e74e902b228c453); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3a018e5b1027c2d16e74e902b228c453)): ?>
<?php $component = $__componentOriginal3a018e5b1027c2d16e74e902b228c453; ?>
<?php unset($__componentOriginal3a018e5b1027c2d16e74e902b228c453); ?>
<?php endif; ?>
        </div>
        <div>
            <?php if (isset($component)) { $__componentOriginalf94ed9c5393ef72725d159fe01139746 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf94ed9c5393ef72725d159fe01139746 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-error','data' => ['for' => 'wardrobe_type','class' => 'mt-2']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('input-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['for' => 'wardrobe_type','class' => 'mt-2']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $attributes = $__attributesOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__attributesOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $component = $__componentOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__componentOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
        </div>
        <p class="mt-5 mb-3 font-bold">Please select finish type:</p>
        <div class="grid grid-cols-2 sm:grid-cols-4  w-full gap-5">
            <?php if (isset($component)) { $__componentOriginal3a018e5b1027c2d16e74e902b228c453 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3a018e5b1027c2d16e74e902b228c453 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.shared.image-radio','data' => ['id' => 'finish_type_acrylic','name' => 'finish_type','src' => ''.e(asset('images/fiddy/wardrobe/acrylic.png')).'','wire:model.live' => 'finish_type','value' => 'acrylic']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('shared.image-radio'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'finish_type_acrylic','name' => 'finish_type','src' => ''.e(asset('images/fiddy/wardrobe/acrylic.png')).'','wire:model.live' => 'finish_type','value' => 'acrylic']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3a018e5b1027c2d16e74e902b228c453)): ?>
<?php $attributes = $__attributesOriginal3a018e5b1027c2d16e74e902b228c453; ?>
<?php unset($__attributesOriginal3a018e5b1027c2d16e74e902b228c453); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3a018e5b1027c2d16e74e902b228c453)): ?>
<?php $component = $__componentOriginal3a018e5b1027c2d16e74e902b228c453; ?>
<?php unset($__componentOriginal3a018e5b1027c2d16e74e902b228c453); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginal3a018e5b1027c2d16e74e902b228c453 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3a018e5b1027c2d16e74e902b228c453 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.shared.image-radio','data' => ['id' => 'finish_type_laminate','name' => 'finish_type','src' => ''.e(asset('images/fiddy/wardrobe/laminate.png')).'','wire:model.live' => 'finish_type','value' => 'laminate']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('shared.image-radio'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'finish_type_laminate','name' => 'finish_type','src' => ''.e(asset('images/fiddy/wardrobe/laminate.png')).'','wire:model.live' => 'finish_type','value' => 'laminate']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3a018e5b1027c2d16e74e902b228c453)): ?>
<?php $attributes = $__attributesOriginal3a018e5b1027c2d16e74e902b228c453; ?>
<?php unset($__attributesOriginal3a018e5b1027c2d16e74e902b228c453); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3a018e5b1027c2d16e74e902b228c453)): ?>
<?php $component = $__componentOriginal3a018e5b1027c2d16e74e902b228c453; ?>
<?php unset($__componentOriginal3a018e5b1027c2d16e74e902b228c453); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginal3a018e5b1027c2d16e74e902b228c453 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3a018e5b1027c2d16e74e902b228c453 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.shared.image-radio','data' => ['id' => 'finish_type_glass','name' => 'finish_type','src' => ''.e(asset('images/fiddy/wardrobe/glass.png')).'','wire:model.live' => 'finish_type','value' => 'glass']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('shared.image-radio'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'finish_type_glass','name' => 'finish_type','src' => ''.e(asset('images/fiddy/wardrobe/glass.png')).'','wire:model.live' => 'finish_type','value' => 'glass']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3a018e5b1027c2d16e74e902b228c453)): ?>
<?php $attributes = $__attributesOriginal3a018e5b1027c2d16e74e902b228c453; ?>
<?php unset($__attributesOriginal3a018e5b1027c2d16e74e902b228c453); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3a018e5b1027c2d16e74e902b228c453)): ?>
<?php $component = $__componentOriginal3a018e5b1027c2d16e74e902b228c453; ?>
<?php unset($__componentOriginal3a018e5b1027c2d16e74e902b228c453); ?>
<?php endif; ?>
        </div>
        <div>
            <?php if (isset($component)) { $__componentOriginalf94ed9c5393ef72725d159fe01139746 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf94ed9c5393ef72725d159fe01139746 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-error','data' => ['for' => 'finish_type','class' => 'mt-2']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('input-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['for' => 'finish_type','class' => 'mt-2']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $attributes = $__attributesOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__attributesOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $component = $__componentOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__componentOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
        </div>
        <p class="mt-5 mb-3 font-bold">Please select material:</p>
        <div class="grid grid-cols-2 sm:grid-cols-4  w-full gap-5">
            <?php if (isset($component)) { $__componentOriginal3a018e5b1027c2d16e74e902b228c453 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3a018e5b1027c2d16e74e902b228c453 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.shared.image-radio','data' => ['id' => 'material_mdf','name' => 'material','src' => ''.e(asset('images/fiddy/wardrobe/mdf.png')).'','wire:model.live' => 'material','value' => 'MDF']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('shared.image-radio'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'material_mdf','name' => 'material','src' => ''.e(asset('images/fiddy/wardrobe/mdf.png')).'','wire:model.live' => 'material','value' => 'MDF']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3a018e5b1027c2d16e74e902b228c453)): ?>
<?php $attributes = $__attributesOriginal3a018e5b1027c2d16e74e902b228c453; ?>
<?php unset($__attributesOriginal3a018e5b1027c2d16e74e902b228c453); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3a018e5b1027c2d16e74e902b228c453)): ?>
<?php $component = $__componentOriginal3a018e5b1027c2d16e74e902b228c453; ?>
<?php unset($__componentOriginal3a018e5b1027c2d16e74e902b228c453); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginal3a018e5b1027c2d16e74e902b228c453 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3a018e5b1027c2d16e74e902b228c453 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.shared.image-radio','data' => ['id' => 'material_hdhmr','name' => 'material','src' => ''.e(asset('images/fiddy/wardrobe/hdhmr.png')).'','wire:model.live' => 'material','value' => 'HDHMR']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('shared.image-radio'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'material_hdhmr','name' => 'material','src' => ''.e(asset('images/fiddy/wardrobe/hdhmr.png')).'','wire:model.live' => 'material','value' => 'HDHMR']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3a018e5b1027c2d16e74e902b228c453)): ?>
<?php $attributes = $__attributesOriginal3a018e5b1027c2d16e74e902b228c453; ?>
<?php unset($__attributesOriginal3a018e5b1027c2d16e74e902b228c453); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3a018e5b1027c2d16e74e902b228c453)): ?>
<?php $component = $__componentOriginal3a018e5b1027c2d16e74e902b228c453; ?>
<?php unset($__componentOriginal3a018e5b1027c2d16e74e902b228c453); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginal3a018e5b1027c2d16e74e902b228c453 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3a018e5b1027c2d16e74e902b228c453 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.shared.image-radio','data' => ['id' => 'material_waterproof_ply','name' => 'material','src' => ''.e(asset('images/fiddy/wardrobe/waterproof_ply.png')).'','wire:model.live' => 'material','value' => 'Waterproof Ply']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('shared.image-radio'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'material_waterproof_ply','name' => 'material','src' => ''.e(asset('images/fiddy/wardrobe/waterproof_ply.png')).'','wire:model.live' => 'material','value' => 'Waterproof Ply']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3a018e5b1027c2d16e74e902b228c453)): ?>
<?php $attributes = $__attributesOriginal3a018e5b1027c2d16e74e902b228c453; ?>
<?php unset($__attributesOriginal3a018e5b1027c2d16e74e902b228c453); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3a018e5b1027c2d16e74e902b228c453)): ?>
<?php $component = $__componentOriginal3a018e5b1027c2d16e74e902b228c453; ?>
<?php unset($__componentOriginal3a018e5b1027c2d16e74e902b228c453); ?>
<?php endif; ?>
        </div>
        <div>
            <?php if (isset($component)) { $__componentOriginalf94ed9c5393ef72725d159fe01139746 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf94ed9c5393ef72725d159fe01139746 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-error','data' => ['for' => 'material','class' => 'mt-2']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('input-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['for' => 'material','class' => 'mt-2']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $attributes = $__attributesOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__attributesOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $component = $__componentOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__componentOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
        </div>        
        <p class="mt-5 mb-2 font-bold">Enter dimensions:</p>
        <div class="grid grid-cols-3 gap-3 sm:gap-5">
            <div class="flex flex-col gap-1">
                <label for="width" class="text-sm">Width (ft)</label>
                <?php if (isset($component)) { $__componentOriginala1c952bd4409e4bd5d7600149cca2017 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala1c952bd4409e4bd5d7600149cca2017 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.shared.text-input','data' => ['class' => 'text-sm','id' => 'width','type' => 'number','required' => true,'step' => '0.1','min' => '1','name' => 'width','wire:model' => 'width','placeholder' => 'Width']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('shared.text-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'text-sm','id' => 'width','type' => 'number','required' => true,'step' => '0.1','min' => '1','name' => 'width','wire:model' => 'width','placeholder' => 'Width']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala1c952bd4409e4bd5d7600149cca2017)): ?>
<?php $attributes = $__attributesOriginala1c952bd4409e4bd5d7600149cca2017; ?>
<?php unset($__attributesOriginala1c952bd4409e4bd5d7600149cca2017); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala1c952bd4409e4bd5d7600149cca2017)): ?>
<?php $component = $__componentOriginala1c952bd4409e4bd5d7600149cca2017; ?>
<?php unset($__componentOriginala1c952bd4409e4bd5d7600149cca2017); ?>
<?php endif; ?>
                <?php if (isset($component)) { $__componentOriginalf94ed9c5393ef72725d159fe01139746 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf94ed9c5393ef72725d159fe01139746 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-error','data' => ['for' => 'width','class' => 'mt-2']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('input-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['for' => 'width','class' => 'mt-2']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $attributes = $__attributesOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__attributesOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $component = $__componentOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__componentOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
            </div>
            <div class="flex flex-col gap-1">
                <label for="height" class="text-sm">Height (ft)</label>
                <?php if (isset($component)) { $__componentOriginala1c952bd4409e4bd5d7600149cca2017 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala1c952bd4409e4bd5d7600149cca2017 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.shared.text-input','data' => ['class' => 'text-sm','id' => 'length','type' => 'number','required' => true,'step' => '0.1','min' => '1','name' => 'height','wire:model' => 'height','placeholder' => 'Height']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('shared.text-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'text-sm','id' => 'length','type' => 'number','required' => true,'step' => '0.1','min' => '1','name' => 'height','wire:model' => 'height','placeholder' => 'Height']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala1c952bd4409e4bd5d7600149cca2017)): ?>
<?php $attributes = $__attributesOriginala1c952bd4409e4bd5d7600149cca2017; ?>
<?php unset($__attributesOriginala1c952bd4409e4bd5d7600149cca2017); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala1c952bd4409e4bd5d7600149cca2017)): ?>
<?php $component = $__componentOriginala1c952bd4409e4bd5d7600149cca2017; ?>
<?php unset($__componentOriginala1c952bd4409e4bd5d7600149cca2017); ?>
<?php endif; ?>
                <?php if (isset($component)) { $__componentOriginalf94ed9c5393ef72725d159fe01139746 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf94ed9c5393ef72725d159fe01139746 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-error','data' => ['for' => 'height','class' => 'mt-2']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('input-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['for' => 'height','class' => 'mt-2']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $attributes = $__attributesOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__attributesOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $component = $__componentOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__componentOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
            </div>
        </div>
        <div class="text-center my-5">
            <button type="submit" class="du-btn rounded-none bg-[#ECC31F] hover:bg-[#FAD337]">Next</button>
        </div>
    </form>
    <?php elseif($step==2): ?>
        <!--[if BLOCK]><![endif]--><?php if(!$saved): ?>
        <h3 class="font-bold text-2xl text-center mb-5">Get Your Price Estimate</h3>
        <form wire:submit.prevent="save">
            <div class="grid grid-cols-1 sm:grid-cols-2 gap-3 sm:gap-5 mt-5">
                <div class="flex flex-col gap-1">
                    <label for="name" class="text-sm">Name</label>
                    <?php if (isset($component)) { $__componentOriginala1c952bd4409e4bd5d7600149cca2017 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala1c952bd4409e4bd5d7600149cca2017 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.shared.text-input','data' => ['class' => 'text-sm','id' => 'name','type' => 'text','name' => 'name','wire:model.live' => 'name','placeholder' => 'Enter your name']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('shared.text-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'text-sm','id' => 'name','type' => 'text','name' => 'name','wire:model.live' => 'name','placeholder' => 'Enter your name']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala1c952bd4409e4bd5d7600149cca2017)): ?>
<?php $attributes = $__attributesOriginala1c952bd4409e4bd5d7600149cca2017; ?>
<?php unset($__attributesOriginala1c952bd4409e4bd5d7600149cca2017); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala1c952bd4409e4bd5d7600149cca2017)): ?>
<?php $component = $__componentOriginala1c952bd4409e4bd5d7600149cca2017; ?>
<?php unset($__componentOriginala1c952bd4409e4bd5d7600149cca2017); ?>
<?php endif; ?>
                    <?php if (isset($component)) { $__componentOriginalf94ed9c5393ef72725d159fe01139746 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf94ed9c5393ef72725d159fe01139746 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-error','data' => ['for' => 'name','class' => 'mt-2']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('input-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['for' => 'name','class' => 'mt-2']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $attributes = $__attributesOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__attributesOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $component = $__componentOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__componentOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
                </div>
                <div class="flex flex-col gap-1">
                    <label for="email" class="text-sm">Email</label>
                    <?php if (isset($component)) { $__componentOriginala1c952bd4409e4bd5d7600149cca2017 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala1c952bd4409e4bd5d7600149cca2017 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.shared.text-input','data' => ['class' => 'text-sm','id' => 'email','type' => 'email','name' => 'email','wire:model.live' => 'email','placeholder' => 'Enter your email']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('shared.text-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'text-sm','id' => 'email','type' => 'email','name' => 'email','wire:model.live' => 'email','placeholder' => 'Enter your email']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala1c952bd4409e4bd5d7600149cca2017)): ?>
<?php $attributes = $__attributesOriginala1c952bd4409e4bd5d7600149cca2017; ?>
<?php unset($__attributesOriginala1c952bd4409e4bd5d7600149cca2017); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala1c952bd4409e4bd5d7600149cca2017)): ?>
<?php $component = $__componentOriginala1c952bd4409e4bd5d7600149cca2017; ?>
<?php unset($__componentOriginala1c952bd4409e4bd5d7600149cca2017); ?>
<?php endif; ?>
                    <?php if (isset($component)) { $__componentOriginalf94ed9c5393ef72725d159fe01139746 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf94ed9c5393ef72725d159fe01139746 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-error','data' => ['for' => 'email','class' => 'mt-2']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('input-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['for' => 'email','class' => 'mt-2']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $attributes = $__attributesOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__attributesOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $component = $__componentOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__componentOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
                </div>
                <div class="flex flex-col gap-1">
                    <label for="phone" class="text-sm">Phone</label>
                    <?php if (isset($component)) { $__componentOriginala1c952bd4409e4bd5d7600149cca2017 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala1c952bd4409e4bd5d7600149cca2017 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.shared.text-input','data' => ['class' => 'text-sm','id' => 'phone','title' => 'Please enter a valid phone number','pattern' => '^\d{10}$','maxlength' => '10','type' => 'tel','name' => 'phone','wire:model.live' => 'phone_number','placeholder' => 'Enter your phone number']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('shared.text-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'text-sm','id' => 'phone','title' => 'Please enter a valid phone number','pattern' => '^\d{10}$','maxlength' => '10','type' => 'tel','name' => 'phone','wire:model.live' => 'phone_number','placeholder' => 'Enter your phone number']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala1c952bd4409e4bd5d7600149cca2017)): ?>
<?php $attributes = $__attributesOriginala1c952bd4409e4bd5d7600149cca2017; ?>
<?php unset($__attributesOriginala1c952bd4409e4bd5d7600149cca2017); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala1c952bd4409e4bd5d7600149cca2017)): ?>
<?php $component = $__componentOriginala1c952bd4409e4bd5d7600149cca2017; ?>
<?php unset($__componentOriginala1c952bd4409e4bd5d7600149cca2017); ?>
<?php endif; ?>
                    <?php if (isset($component)) { $__componentOriginalf94ed9c5393ef72725d159fe01139746 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf94ed9c5393ef72725d159fe01139746 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-error','data' => ['for' => 'phone_number','class' => 'mt-2']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('input-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['for' => 'phone_number','class' => 'mt-2']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $attributes = $__attributesOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__attributesOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $component = $__componentOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__componentOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
                </div>
            </div>
            <!--[if BLOCK]><![endif]--><?php if(!empty($name) && !empty($email) && !empty($phone_number)): ?>
            <div class="text-center mt-5">
                <button type="submit" class="du-btn rounded-none bg-[#ECC31F] hover:bg-[#FAD337]">Get Estimate</button>
            </div>
            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
        </form>
        <?php else: ?>
        <h3 class="font-bold text-2xl text-center mb-5">Wardrobe Estimate</h3>
        <div class="flex flex-col gap-1 items-center">
            <div class="flex gap-1 items-start">
                <span class="font-semibold">Shape:</span>
                <span><?php echo e(ucwords($wardrobe_type)); ?> (<?php echo e(ucwords($finish_type)); ?>, <?php echo e($material); ?>)</span>
            </div>
            <div class="px-5 sm:px-0">
                <?php
                    $src="images/fiddy/wardrobe/$wardrobe_type.png";
                ?>
                <img src="<?php echo e(asset($src)); ?>" class="sm:h-44 cursor-pointer min-h-10 min-w-10 w-full resize object-cover group-hover:border-gray-700 border-2 border-transparent" />
            </div>
            <div class="flex gap-3 text-sm flex-wrap">
                <div class="flex flex-col gap-1">
                    <span class="underline underline-offset-2">Size</span>
                    <span>(<?php echo e($width); ?>x<?php echo e($height); ?>)</span>
                </div>
            </div>
        </div>
        <p class="text-center mt-5">
            Your total estimate is: <strong><?php echo e($estimate); ?> (incl. GST)</strong>
            <br/>
            <span class="italic">* Terms and Conditions Apply</span>
        </p>
        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
</div><?php /**PATH D:\PROJECTS\Laravel\fiddy-laravel\resources\views/livewire/forms/wardrobe-estimator-form.blade.php ENDPATH**/ ?>