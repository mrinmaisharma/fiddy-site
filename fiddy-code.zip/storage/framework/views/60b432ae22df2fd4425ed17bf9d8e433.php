<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps(['id'=>'','src'=>'', 'class'=>""]) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps(['id'=>'','src'=>'', 'class'=>""]); ?>
<?php foreach (array_filter((['id'=>'','src'=>'', 'class'=>""]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>
<span class="relative group image-radio-container">
    <input type="radio" id="<?php echo e($id); ?>" class="hidden" <?php echo e($attributes); ?> />
    <label for="<?php echo e($id); ?>">
        <img src="<?php echo e($src); ?>" class="cursor-pointer min-h-10 min-w-10 w-full resize object-cover group-hover:border-gray-700 border-2 border-transparent" />
    </label>
</span><?php /**PATH D:\PROJECTS\Laravel\fiddy-laravel\resources\views/components/shared/image-radio.blade.php ENDPATH**/ ?>