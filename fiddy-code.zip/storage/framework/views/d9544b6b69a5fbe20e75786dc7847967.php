<div >
    <!--[if BLOCK]><![endif]--><?php if($step==1): ?>
    <form wire:submit.prevent="openForm">
        <?php echo csrf_field(); ?>
        <?php if (isset($component)) { $__componentOriginalb24df6adf99a77ed35057e476f61e153 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb24df6adf99a77ed35057e476f61e153 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.validation-errors','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('validation-errors'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb24df6adf99a77ed35057e476f61e153)): ?>
<?php $attributes = $__attributesOriginalb24df6adf99a77ed35057e476f61e153; ?>
<?php unset($__attributesOriginalb24df6adf99a77ed35057e476f61e153); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb24df6adf99a77ed35057e476f61e153)): ?>
<?php $component = $__componentOriginalb24df6adf99a77ed35057e476f61e153; ?>
<?php unset($__componentOriginalb24df6adf99a77ed35057e476f61e153); ?>
<?php endif; ?>
        <p class="mb-5 font-bold">Please select kitchen type:</p>
        <div class="grid grid-cols-2 sm:grid-cols-4  w-full gap-5">
            <?php if (isset($component)) { $__componentOriginal3a018e5b1027c2d16e74e902b228c453 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3a018e5b1027c2d16e74e902b228c453 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.shared.image-radio','data' => ['id' => 'kitchen_type_straight','name' => 'kitchen_type','src' => ''.e(asset('images/fiddy/kitchen/straight.png')).'','wire:model.live' => 'kitchen_type','value' => 'straight']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('shared.image-radio'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'kitchen_type_straight','name' => 'kitchen_type','src' => ''.e(asset('images/fiddy/kitchen/straight.png')).'','wire:model.live' => 'kitchen_type','value' => 'straight']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3a018e5b1027c2d16e74e902b228c453)): ?>
<?php $attributes = $__attributesOriginal3a018e5b1027c2d16e74e902b228c453; ?>
<?php unset($__attributesOriginal3a018e5b1027c2d16e74e902b228c453); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3a018e5b1027c2d16e74e902b228c453)): ?>
<?php $component = $__componentOriginal3a018e5b1027c2d16e74e902b228c453; ?>
<?php unset($__componentOriginal3a018e5b1027c2d16e74e902b228c453); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginal3a018e5b1027c2d16e74e902b228c453 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3a018e5b1027c2d16e74e902b228c453 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.shared.image-radio','data' => ['id' => 'kitchen_type_parallel','name' => 'kitchen_type','src' => ''.e(asset('images/fiddy/kitchen/parallel.png')).'','wire:model.live' => 'kitchen_type','value' => 'parallel']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('shared.image-radio'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'kitchen_type_parallel','name' => 'kitchen_type','src' => ''.e(asset('images/fiddy/kitchen/parallel.png')).'','wire:model.live' => 'kitchen_type','value' => 'parallel']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3a018e5b1027c2d16e74e902b228c453)): ?>
<?php $attributes = $__attributesOriginal3a018e5b1027c2d16e74e902b228c453; ?>
<?php unset($__attributesOriginal3a018e5b1027c2d16e74e902b228c453); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3a018e5b1027c2d16e74e902b228c453)): ?>
<?php $component = $__componentOriginal3a018e5b1027c2d16e74e902b228c453; ?>
<?php unset($__componentOriginal3a018e5b1027c2d16e74e902b228c453); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginal3a018e5b1027c2d16e74e902b228c453 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3a018e5b1027c2d16e74e902b228c453 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.shared.image-radio','data' => ['id' => 'kitchen_type_lshaped','name' => 'kitchen_type','src' => ''.e(asset('images/fiddy/kitchen/l-shaped.png')).'','wire:model.live' => 'kitchen_type','value' => 'l-shaped']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('shared.image-radio'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'kitchen_type_lshaped','name' => 'kitchen_type','src' => ''.e(asset('images/fiddy/kitchen/l-shaped.png')).'','wire:model.live' => 'kitchen_type','value' => 'l-shaped']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3a018e5b1027c2d16e74e902b228c453)): ?>
<?php $attributes = $__attributesOriginal3a018e5b1027c2d16e74e902b228c453; ?>
<?php unset($__attributesOriginal3a018e5b1027c2d16e74e902b228c453); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3a018e5b1027c2d16e74e902b228c453)): ?>
<?php $component = $__componentOriginal3a018e5b1027c2d16e74e902b228c453; ?>
<?php unset($__componentOriginal3a018e5b1027c2d16e74e902b228c453); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginal3a018e5b1027c2d16e74e902b228c453 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3a018e5b1027c2d16e74e902b228c453 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.shared.image-radio','data' => ['id' => 'kitchen_type_ushaped','name' => 'kitchen_type','src' => ''.e(asset('images/fiddy/kitchen/u-shaped.png')).'','wire:model.live' => 'kitchen_type','value' => 'u-shaped']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('shared.image-radio'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'kitchen_type_ushaped','name' => 'kitchen_type','src' => ''.e(asset('images/fiddy/kitchen/u-shaped.png')).'','wire:model.live' => 'kitchen_type','value' => 'u-shaped']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3a018e5b1027c2d16e74e902b228c453)): ?>
<?php $attributes = $__attributesOriginal3a018e5b1027c2d16e74e902b228c453; ?>
<?php unset($__attributesOriginal3a018e5b1027c2d16e74e902b228c453); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3a018e5b1027c2d16e74e902b228c453)): ?>
<?php $component = $__componentOriginal3a018e5b1027c2d16e74e902b228c453; ?>
<?php unset($__componentOriginal3a018e5b1027c2d16e74e902b228c453); ?>
<?php endif; ?>
        </div>
        <div>
            <?php if (isset($component)) { $__componentOriginalf94ed9c5393ef72725d159fe01139746 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf94ed9c5393ef72725d159fe01139746 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-error','data' => ['for' => 'kitchen_type','class' => 'mt-2']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('input-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['for' => 'kitchen_type','class' => 'mt-2']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $attributes = $__attributesOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__attributesOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $component = $__componentOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__componentOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
        </div>
        <p class="mb-5 font-bold">Please select finish type:</p>
        <div class="grid grid-cols-2 sm:grid-cols-4  w-full gap-5">
            <?php if (isset($component)) { $__componentOriginal3a018e5b1027c2d16e74e902b228c453 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3a018e5b1027c2d16e74e902b228c453 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.shared.image-radio','data' => ['id' => 'finish_type_acrylic','name' => 'finish_type','src' => ''.e(asset('images/fiddy/kitchen/acrylic.png')).'','wire:model.live' => 'finish_type','value' => 'acrylic']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('shared.image-radio'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'finish_type_acrylic','name' => 'finish_type','src' => ''.e(asset('images/fiddy/kitchen/acrylic.png')).'','wire:model.live' => 'finish_type','value' => 'acrylic']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3a018e5b1027c2d16e74e902b228c453)): ?>
<?php $attributes = $__attributesOriginal3a018e5b1027c2d16e74e902b228c453; ?>
<?php unset($__attributesOriginal3a018e5b1027c2d16e74e902b228c453); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3a018e5b1027c2d16e74e902b228c453)): ?>
<?php $component = $__componentOriginal3a018e5b1027c2d16e74e902b228c453; ?>
<?php unset($__componentOriginal3a018e5b1027c2d16e74e902b228c453); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginal3a018e5b1027c2d16e74e902b228c453 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3a018e5b1027c2d16e74e902b228c453 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.shared.image-radio','data' => ['id' => 'finish_type_laminate','name' => 'finish_type','src' => ''.e(asset('images/fiddy/kitchen/laminate.png')).'','wire:model.live' => 'finish_type','value' => 'laminate']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('shared.image-radio'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'finish_type_laminate','name' => 'finish_type','src' => ''.e(asset('images/fiddy/kitchen/laminate.png')).'','wire:model.live' => 'finish_type','value' => 'laminate']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3a018e5b1027c2d16e74e902b228c453)): ?>
<?php $attributes = $__attributesOriginal3a018e5b1027c2d16e74e902b228c453; ?>
<?php unset($__attributesOriginal3a018e5b1027c2d16e74e902b228c453); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3a018e5b1027c2d16e74e902b228c453)): ?>
<?php $component = $__componentOriginal3a018e5b1027c2d16e74e902b228c453; ?>
<?php unset($__componentOriginal3a018e5b1027c2d16e74e902b228c453); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginal3a018e5b1027c2d16e74e902b228c453 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3a018e5b1027c2d16e74e902b228c453 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.shared.image-radio','data' => ['id' => 'finish_type_pu','name' => 'finish_type','src' => ''.e(asset('images/fiddy/kitchen/pu.png')).'','wire:model.live' => 'finish_type','value' => 'PU']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('shared.image-radio'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'finish_type_pu','name' => 'finish_type','src' => ''.e(asset('images/fiddy/kitchen/pu.png')).'','wire:model.live' => 'finish_type','value' => 'PU']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3a018e5b1027c2d16e74e902b228c453)): ?>
<?php $attributes = $__attributesOriginal3a018e5b1027c2d16e74e902b228c453; ?>
<?php unset($__attributesOriginal3a018e5b1027c2d16e74e902b228c453); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3a018e5b1027c2d16e74e902b228c453)): ?>
<?php $component = $__componentOriginal3a018e5b1027c2d16e74e902b228c453; ?>
<?php unset($__componentOriginal3a018e5b1027c2d16e74e902b228c453); ?>
<?php endif; ?>
        </div>
        <div>
            <?php if (isset($component)) { $__componentOriginalf94ed9c5393ef72725d159fe01139746 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf94ed9c5393ef72725d159fe01139746 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-error','data' => ['for' => 'finish_type','class' => 'mt-2']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('input-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['for' => 'finish_type','class' => 'mt-2']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $attributes = $__attributesOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__attributesOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $component = $__componentOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__componentOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
        </div>
        <!--[if BLOCK]><![endif]--><?php if($kitchen_type!='0'): ?>
        <p class="mt-5 mb-2 font-bold">Enter kitchen dimensions:</p>
        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
        <?php
            $typeSides=[
                '0'=>[],
                'straight'=>['A'],
                'parallel'=>['A','B'],
                'l-shaped'=>['A','B'],
                'u-shaped'=>['A','B','C']
            ];
        ?>
        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $typeSides[$kitchen_type]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <p class="text-sm  mt-5 mb-2 underline underline-offset-2">Side <?php echo e($s); ?>:</p>
        <div class="grid grid-cols-3 gap-3 sm:gap-5">
            <div class="flex flex-col gap-1">
                <label for="length<?php echo e($s); ?>" class="text-sm">Length (ft)</label>
                <?php if (isset($component)) { $__componentOriginala1c952bd4409e4bd5d7600149cca2017 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala1c952bd4409e4bd5d7600149cca2017 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.shared.text-input','data' => ['class' => 'text-sm','id' => 'length'.e($s).'','type' => 'number','required' => true,'step' => '0.1','min' => '1','name' => 'length'.e($s).'','wire:model' => 'length_'.e(strtolower($s)).'','placeholder' => 'Length']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('shared.text-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'text-sm','id' => 'length'.e($s).'','type' => 'number','required' => true,'step' => '0.1','min' => '1','name' => 'length'.e($s).'','wire:model' => 'length_'.e(strtolower($s)).'','placeholder' => 'Length']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala1c952bd4409e4bd5d7600149cca2017)): ?>
<?php $attributes = $__attributesOriginala1c952bd4409e4bd5d7600149cca2017; ?>
<?php unset($__attributesOriginala1c952bd4409e4bd5d7600149cca2017); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala1c952bd4409e4bd5d7600149cca2017)): ?>
<?php $component = $__componentOriginala1c952bd4409e4bd5d7600149cca2017; ?>
<?php unset($__componentOriginala1c952bd4409e4bd5d7600149cca2017); ?>
<?php endif; ?>
                <?php if (isset($component)) { $__componentOriginalf94ed9c5393ef72725d159fe01139746 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf94ed9c5393ef72725d159fe01139746 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-error','data' => ['for' => 'length_'.e(strtolower($s)).'','class' => 'mt-2']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('input-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['for' => 'length_'.e(strtolower($s)).'','class' => 'mt-2']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $attributes = $__attributesOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__attributesOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $component = $__componentOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__componentOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
            </div>
            <div class="flex flex-col gap-1">
                <label for="breadth<?php echo e($s); ?>" class="text-sm">Slab Depth (ft)</label>
                <?php if (isset($component)) { $__componentOriginala1c952bd4409e4bd5d7600149cca2017 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala1c952bd4409e4bd5d7600149cca2017 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.shared.text-input','data' => ['class' => 'text-sm','id' => 'breadth'.e($s).'','type' => 'number','disabled' => true,'required' => true,'step' => '0.1','min' => '1','name' => 'breadth'.e($s).'','wire:model' => 'breadth_'.e(strtolower($s)).'','placeholder' => 'Breadth']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('shared.text-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'text-sm','id' => 'breadth'.e($s).'','type' => 'number','disabled' => true,'required' => true,'step' => '0.1','min' => '1','name' => 'breadth'.e($s).'','wire:model' => 'breadth_'.e(strtolower($s)).'','placeholder' => 'Breadth']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala1c952bd4409e4bd5d7600149cca2017)): ?>
<?php $attributes = $__attributesOriginala1c952bd4409e4bd5d7600149cca2017; ?>
<?php unset($__attributesOriginala1c952bd4409e4bd5d7600149cca2017); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala1c952bd4409e4bd5d7600149cca2017)): ?>
<?php $component = $__componentOriginala1c952bd4409e4bd5d7600149cca2017; ?>
<?php unset($__componentOriginala1c952bd4409e4bd5d7600149cca2017); ?>
<?php endif; ?>
                <?php if (isset($component)) { $__componentOriginalf94ed9c5393ef72725d159fe01139746 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf94ed9c5393ef72725d159fe01139746 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-error','data' => ['for' => 'breadth_'.e(strtolower($s)).'','class' => 'mt-2']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('input-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['for' => 'breadth_'.e(strtolower($s)).'','class' => 'mt-2']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $attributes = $__attributesOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__attributesOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $component = $__componentOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__componentOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
            </div>
            
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
        <div class="text-center my-5">
            <button type="submit" class="du-btn rounded-none bg-[#ECC31F] hover:bg-[#FAD337]">Next</button>
        </div>
    </form>
    <?php elseif($step==2): ?>
        <!--[if BLOCK]><![endif]--><?php if(!$saved): ?>
        <h3 class="font-bold text-2xl text-center mb-5">Get Your Price Estimate</h3>
        <form wire:submit.prevent="save">
            <div class="grid grid-cols-1 sm:grid-cols-2 gap-3 sm:gap-5 mt-5">
                <div class="flex flex-col gap-1">
                    <label for="name" class="text-sm">Name</label>
                    <?php if (isset($component)) { $__componentOriginala1c952bd4409e4bd5d7600149cca2017 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala1c952bd4409e4bd5d7600149cca2017 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.shared.text-input','data' => ['class' => 'text-sm','id' => 'name','type' => 'text','name' => 'name','wire:model.live' => 'name','placeholder' => 'Enter your name']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('shared.text-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'text-sm','id' => 'name','type' => 'text','name' => 'name','wire:model.live' => 'name','placeholder' => 'Enter your name']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala1c952bd4409e4bd5d7600149cca2017)): ?>
<?php $attributes = $__attributesOriginala1c952bd4409e4bd5d7600149cca2017; ?>
<?php unset($__attributesOriginala1c952bd4409e4bd5d7600149cca2017); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala1c952bd4409e4bd5d7600149cca2017)): ?>
<?php $component = $__componentOriginala1c952bd4409e4bd5d7600149cca2017; ?>
<?php unset($__componentOriginala1c952bd4409e4bd5d7600149cca2017); ?>
<?php endif; ?>
                    <?php if (isset($component)) { $__componentOriginalf94ed9c5393ef72725d159fe01139746 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf94ed9c5393ef72725d159fe01139746 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-error','data' => ['for' => 'name','class' => 'mt-2']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('input-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['for' => 'name','class' => 'mt-2']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $attributes = $__attributesOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__attributesOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $component = $__componentOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__componentOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
                </div>
                <div class="flex flex-col gap-1">
                    <label for="email" class="text-sm">Email</label>
                    <?php if (isset($component)) { $__componentOriginala1c952bd4409e4bd5d7600149cca2017 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala1c952bd4409e4bd5d7600149cca2017 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.shared.text-input','data' => ['class' => 'text-sm','id' => 'email','type' => 'email','name' => 'email','wire:model.live' => 'email','placeholder' => 'Enter your email']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('shared.text-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'text-sm','id' => 'email','type' => 'email','name' => 'email','wire:model.live' => 'email','placeholder' => 'Enter your email']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala1c952bd4409e4bd5d7600149cca2017)): ?>
<?php $attributes = $__attributesOriginala1c952bd4409e4bd5d7600149cca2017; ?>
<?php unset($__attributesOriginala1c952bd4409e4bd5d7600149cca2017); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala1c952bd4409e4bd5d7600149cca2017)): ?>
<?php $component = $__componentOriginala1c952bd4409e4bd5d7600149cca2017; ?>
<?php unset($__componentOriginala1c952bd4409e4bd5d7600149cca2017); ?>
<?php endif; ?>
                    <?php if (isset($component)) { $__componentOriginalf94ed9c5393ef72725d159fe01139746 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf94ed9c5393ef72725d159fe01139746 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-error','data' => ['for' => 'email','class' => 'mt-2']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('input-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['for' => 'email','class' => 'mt-2']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $attributes = $__attributesOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__attributesOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $component = $__componentOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__componentOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
                </div>
                <div class="flex flex-col gap-1">
                    <label for="phone" class="text-sm">Phone</label>
                    <?php if (isset($component)) { $__componentOriginala1c952bd4409e4bd5d7600149cca2017 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala1c952bd4409e4bd5d7600149cca2017 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.shared.text-input','data' => ['class' => 'text-sm','id' => 'phone','title' => 'Please enter a valid phone number','pattern' => '^\d{10}$','maxlength' => '10','type' => 'tel','name' => 'phone','wire:model.live' => 'phone_number','placeholder' => 'Enter your phone number']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('shared.text-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'text-sm','id' => 'phone','title' => 'Please enter a valid phone number','pattern' => '^\d{10}$','maxlength' => '10','type' => 'tel','name' => 'phone','wire:model.live' => 'phone_number','placeholder' => 'Enter your phone number']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala1c952bd4409e4bd5d7600149cca2017)): ?>
<?php $attributes = $__attributesOriginala1c952bd4409e4bd5d7600149cca2017; ?>
<?php unset($__attributesOriginala1c952bd4409e4bd5d7600149cca2017); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala1c952bd4409e4bd5d7600149cca2017)): ?>
<?php $component = $__componentOriginala1c952bd4409e4bd5d7600149cca2017; ?>
<?php unset($__componentOriginala1c952bd4409e4bd5d7600149cca2017); ?>
<?php endif; ?>
                    <?php if (isset($component)) { $__componentOriginalf94ed9c5393ef72725d159fe01139746 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf94ed9c5393ef72725d159fe01139746 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-error','data' => ['for' => 'phone_number','class' => 'mt-2']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('input-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['for' => 'phone_number','class' => 'mt-2']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $attributes = $__attributesOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__attributesOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $component = $__componentOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__componentOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
                </div>
            </div>
            <!--[if BLOCK]><![endif]--><?php if(!empty($name) && !empty($email) && !empty($phone_number)): ?>
            <div class="text-center mt-5">
                <button type="submit" class="du-btn rounded-none bg-[#ECC31F] hover:bg-[#FAD337]">Get Estimate</button>
            </div>
            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
        </form>
        <?php else: ?>
        <h3 class="font-bold text-2xl text-center mb-5">Kitchen Estimate</h3>
        <div class="flex flex-col gap-1 items-center">
            <div class="flex gap-1 items-start">
                <span class="font-semibold">Shape:</span>
                <span><?php echo e(ucwords($kitchen_type)); ?> (<?php echo e(ucwords($finish_type)); ?>)</span>
            </div>
            <div class="px-5 sm:px-0">
                <?php
                    $src="images/fiddy/kitchen/$kitchen_type.png";
                ?>
                <img src="<?php echo e(asset($src)); ?>" class="sm:h-44 cursor-pointer min-h-10 min-w-10 w-full resize object-cover group-hover:border-gray-700 border-2 border-transparent" />
            </div>
            <div class="flex gap-3 text-sm flex-wrap">
                <div class="flex flex-col gap-1">
                    <span class="underline underline-offset-2">Side A</span>
                    <span>(<?php echo e($length_a); ?>x<?php echo e($breadth_a); ?>)</span>
                </div>
                <!--[if BLOCK]><![endif]--><?php if($this->kitchen_type!='straight'): ?>
                    <div class="flex flex-col gap-1">
                        <span class="underline underline-offset-2">Side B</span> 
                        <span>(<?php echo e($length_b); ?>x<?php echo e($breadth_b); ?>)</span>
                    </div>
                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                <!--[if BLOCK]><![endif]--><?php if($kitchen_type=='u-shaped'): ?>
                    <div class="flex flex-col gap-1">
                        <span class="underline underline-offset-2">Side C</span>
                        <span>(<?php echo e($length_c); ?>x<?php echo e($breadth_c); ?>)</span>
                    </div>
                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
            </div>
        </div>
        <p class="text-center mt-5">
            Your total estimate is: <strong><?php echo e($estimate); ?> (incl. GST)</strong>
            <br/>
            <span class="italic">* Terms and Conditions Apply</span>
        </p>
        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
</div>
<?php /**PATH D:\PROJECTS\Laravel\fiddy-laravel\resources\views/livewire/forms/kitchen-estimator-form.blade.php ENDPATH**/ ?>